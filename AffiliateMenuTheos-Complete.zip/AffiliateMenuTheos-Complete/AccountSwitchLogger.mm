#import "AccountSwitchLogger.h"
#import "IntegrationContract.h"

@implementation AMAccountSwitchLogger {
    NSDateFormatter *_formatter;
}

+ (instancetype)sharedInstance {
    static AMAccountSwitchLogger *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [AMAccountSwitchLogger new]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _formatter = [NSDateFormatter new];
        _formatter.dateFormat = @"HH:mm:ss";
        _formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    }
    return self;
}

- (NSString *)defaultsKey:(NSInteger)profileIndex {
    return [NSString stringWithFormat:@"AffiliateMenu.switchLog.%ld", (long)profileIndex];
}

- (void)appendMessage:(NSString *)message level:(NSString *)level profileIndex:(NSInteger)profileIndex {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *timestamp = [self->_formatter stringFromDate:NSDate.date];
        NSString *safeMessage = message.length ? message : @"(no message)";
        NSString *entry = [NSString stringWithFormat:@"%@ [%@] %@", timestamp, level.uppercaseString, safeMessage];
        NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
        NSMutableArray<NSString *> *entries = [[defaults stringArrayForKey:[self defaultsKey:profileIndex]] ?: @[] mutableCopy];
        [entries addObject:entry];
        if (entries.count > 300) [entries removeObjectsInRange:NSMakeRange(0, entries.count - 300)];
        [defaults setObject:entries forKey:[self defaultsKey:profileIndex]];
        [NSNotificationCenter.defaultCenter postNotificationName:AMAccountSwitchLogDidChangeNotification object:self userInfo:@{AMIntegrationProfileIndexKey:@(profileIndex)}];
    });
}

- (NSArray<NSString *> *)entriesForProfileIndex:(NSInteger)profileIndex {
    return [NSUserDefaults.standardUserDefaults stringArrayForKey:[self defaultsKey:profileIndex]] ?: @[];
}

- (void)clearProfileIndex:(NSInteger)profileIndex {
    [NSUserDefaults.standardUserDefaults removeObjectForKey:[self defaultsKey:profileIndex]];
    [NSNotificationCenter.defaultCenter postNotificationName:AMAccountSwitchLogDidChangeNotification object:self userInfo:@{AMIntegrationProfileIndexKey:@(profileIndex)}];
}

@end
