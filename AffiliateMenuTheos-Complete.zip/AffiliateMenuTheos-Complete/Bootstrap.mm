#import "Bootstrap.h"
#import <UIKit/UIKit.h>
#import "Menu.h"
#import "TargetConfig.h"
#import "WindowResolver.h"

@implementation AMBootstrap {
    BOOL _started;
}

+ (instancetype)sharedInstance {
    static AMBootstrap *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [AMBootstrap new]; });
    return instance;
}

- (void)start {
    NSAssert(NSThread.isMainThread, @"AMBootstrap must start on the main thread");
    if (_started) {
        [self attemptMenuInitialization];
        return;
    }
    _started = YES;

    NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
    [center addObserver:self selector:@selector(applicationEvent:) name:UIApplicationDidFinishLaunchingNotification object:nil];
    [center addObserver:self selector:@selector(applicationEvent:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [self attemptMenuInitialization];
}

- (void)applicationEvent:(NSNotification *)notification {
    (void)notification;
    [self attemptMenuInitialization];
}

- (BOOL)isAllowedHostApplication {
    if (AMTargetBundleID.length == 0) return YES;
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier ?: @"";
    return [bundleID isEqualToString:AMTargetBundleID];
}

- (void)attemptMenuInitialization {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self attemptMenuInitialization]; });
        return;
    }
    if (![self isAllowedHostApplication]) return;

    UIWindow *window = [AMWindowResolver bestApplicationWindow];
    if (!window) {
        // Do not mark initialization as complete. Launch/active notifications will retry.
        return;
    }
    [[AMMenu sharedInstance] ensureInstalledInWindow:window];
}

@end

__attribute__((constructor)) static void AMStandaloneDylibConstructor(void) {
    // UIKit is intentionally not touched on the loader thread.
    dispatch_async(dispatch_get_main_queue(), ^{
        [[AMBootstrap sharedInstance] start];
    });
}
