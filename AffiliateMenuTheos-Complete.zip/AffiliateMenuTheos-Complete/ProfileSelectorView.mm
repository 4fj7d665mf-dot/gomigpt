#import "ProfileSelectorView.h"

@implementation AMProfileSelectorView {
    NSMutableArray<UIButton *> *_buttons;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) [self buildUI];
    return self;
}

- (void)buildUI {
    _buttons = [NSMutableArray arrayWithCapacity:10];
    UIStackView *vertical = [[UIStackView alloc] init];
    vertical.axis = UILayoutConstraintAxisVertical;
    vertical.spacing = 7.0;
    vertical.distribution = UIStackViewDistributionFillEqually;
    vertical.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:vertical];
    [NSLayoutConstraint activateConstraints:@[
        [vertical.topAnchor constraintEqualToAnchor:self.topAnchor],
        [vertical.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
        [vertical.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [vertical.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [self.heightAnchor constraintEqualToConstant:72.0]
    ]];

    for (NSInteger row = 0; row < 2; row++) {
        UIStackView *horizontal = [[UIStackView alloc] init];
        horizontal.axis = UILayoutConstraintAxisHorizontal;
        horizontal.spacing = 7.0;
        horizontal.distribution = UIStackViewDistributionFillEqually;
        [vertical addArrangedSubview:horizontal];
        for (NSInteger column = 0; column < 5; column++) {
            NSInteger index = row * 5 + column + 1;
            UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
            [button setTitle:[NSString stringWithFormat:@"%ld", (long)index] forState:UIControlStateNormal];
            [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
            button.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
            button.tag = index;
            button.layer.cornerRadius = 8.0;
            button.layer.borderWidth = 1.0;
            [button addTarget:self action:@selector(profileTapped:) forControlEvents:UIControlEventTouchUpInside];
            [horizontal addArrangedSubview:button];
            [_buttons addObject:button];
        }
    }
    self.selectedIndex = 1;
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    _selectedIndex = MAX(1, MIN(10, selectedIndex));
    for (UIButton *button in _buttons) {
        BOOL selected = button.tag == _selectedIndex;
        button.backgroundColor = selected ? [UIColor colorWithWhite:0.35 alpha:1.0] : [UIColor colorWithWhite:0.12 alpha:1.0];
        button.layer.borderColor = (selected ? [UIColor colorWithWhite:0.9 alpha:0.9] : [UIColor colorWithWhite:0.35 alpha:0.8]).CGColor;
    }
}

- (void)profileTapped:(UIButton *)sender {
    self.selectedIndex = sender.tag;
    [self.delegate profileSelectorView:self didSelectProfileIndex:sender.tag];
}

@end
