#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMAccountStatusView : UIView
@property(nonatomic, assign) NSInteger profileIndex;
- (void)reloadStatus;
@end

NS_ASSUME_NONNULL_END
