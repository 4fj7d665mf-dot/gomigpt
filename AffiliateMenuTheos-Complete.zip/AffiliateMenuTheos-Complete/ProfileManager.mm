#import "ProfileManager.h"
#import "KeychainStore.h"
#import "Profile.h"

static NSString * const AMSelectedProfileKey = @"AffiliateMenu.selectedProfile";

@implementation AMProfileManager

+ (instancetype)sharedInstance {
    static AMProfileManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [AMProfileManager new]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        NSInteger saved = [NSUserDefaults.standardUserDefaults integerForKey:AMSelectedProfileKey];
        _selectedProfileIndex = (saved >= 1 && saved <= 10) ? saved : 1;
    }
    return self;
}

- (void)setSelectedProfileIndex:(NSInteger)selectedProfileIndex {
    NSInteger clamped = MAX(1, MIN(10, selectedProfileIndex));
    _selectedProfileIndex = clamped;
    [NSUserDefaults.standardUserDefaults setInteger:clamped forKey:AMSelectedProfileKey];
}

- (NSString *)key:(NSString *)field index:(NSInteger)index {
    return [NSString stringWithFormat:@"AffiliateMenu.profile.%ld.%@", (long)index, field];
}

- (AMProfile *)profileForIndex:(NSInteger)index {
    NSInteger normalized = MAX(1, MIN(10, index));
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    AMProfile *profile = [AMProfile new];
    profile.index = normalized;
    profile.profileName = [defaults stringForKey:[self key:@"name" index:normalized]] ?: [NSString stringWithFormat:@"Affiliate-%02ld", (long)normalized];
    if ([defaults objectForKey:[self key:@"uaPreset" index:normalized]]) {
        profile.selectedUAPreset = (AMUAPreset)[defaults integerForKey:[self key:@"uaPreset" index:normalized]];
    } else {
        profile.selectedUAPreset = AMUAPresetSafariIOS;
    }
    profile.customUserAgent = [defaults stringForKey:[self key:@"customUA" index:normalized]] ?: @"";
    return profile;
}

- (BOOL)saveProfile:(AMProfile *)profile sessionID:(NSString *)sessionID error:(NSError **)error {
    if (profile.index < 1 || profile.index > 10) return NO;
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    [defaults setObject:profile.profileName ?: @"" forKey:[self key:@"name" index:profile.index]];
    [defaults setInteger:profile.selectedUAPreset forKey:[self key:@"uaPreset" index:profile.index]];
    [defaults setObject:profile.customUserAgent ?: @"" forKey:[self key:@"customUA" index:profile.index]];
    return [AMKeychainStore setSessionID:sessionID ?: @"" forProfileIndex:profile.index error:error];
}

- (NSString *)sessionIDForProfileIndex:(NSInteger)index {
    return [AMKeychainStore sessionIDForProfileIndex:index] ?: @"";
}

- (void)resetProfileAtIndex:(NSInteger)index {
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    [defaults removeObjectForKey:[self key:@"name" index:index]];
    [defaults removeObjectForKey:[self key:@"uaPreset" index:index]];
    [defaults removeObjectForKey:[self key:@"customUA" index:index]];
    [AMKeychainStore deleteSessionIDForProfileIndex:index error:nil];
}

@end
