#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// Set this to your app's bundle identifier when known.
// Empty string means "allow any host app" so the base can be tested before final integration.
static NSString * const AMTargetBundleID = @"";
static NSString * const AMDefaultsSuitePrefix = @"AffiliateMenu";

NS_ASSUME_NONNULL_END
