#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMAccountSwitchLogger : NSObject
+ (instancetype)sharedInstance;
- (void)appendMessage:(NSString *)message level:(NSString *)level profileIndex:(NSInteger)profileIndex;
- (NSArray<NSString *> *)entriesForProfileIndex:(NSInteger)profileIndex;
- (void)clearProfileIndex:(NSInteger)profileIndex;
@end

NS_ASSUME_NONNULL_END
