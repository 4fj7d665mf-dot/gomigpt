#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMMenu : NSObject
+ (instancetype)sharedInstance;
- (void)ensureInstalledInWindow:(UIWindow *)window;
@end

NS_ASSUME_NONNULL_END
