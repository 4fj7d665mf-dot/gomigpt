#import "IntegrationContract.h"

NSNotificationName const AMAccountSwitchRequestNotification = @"AffiliateMenu.AccountSwitch.Request";
NSNotificationName const AMAccountSwitchResultNotification = @"AffiliateMenu.AccountSwitch.Result";
NSNotificationName const AMAccountSwitchLogDidChangeNotification = @"AffiliateMenu.AccountSwitch.LogDidChange";

NSNotificationName const AMShadowbanCheckRequestNotification = @"AffiliateMenu.Shadowban.Request";
NSNotificationName const AMShadowbanCheckResultNotification = @"AffiliateMenu.Shadowban.Result";
NSNotificationName const AMShadowbanStatusDidChangeNotification = @"AffiliateMenu.Shadowban.StatusDidChange";

NSString * const AMIntegrationTokenKey = @"token";
NSString * const AMIntegrationProfileIndexKey = @"profileIndex";
NSString * const AMIntegrationProfileNameKey = @"profileName";
NSString * const AMIntegrationSessionIDKey = @"sessionid";
NSString * const AMIntegrationUserAgentKey = @"userAgent";
NSString * const AMIntegrationSuccessKey = @"success";
NSString * const AMIntegrationMessageKey = @"message";
NSString * const AMIntegrationAccountNameKey = @"accountName";
NSString * const AMIntegrationShadowbanStatusKey = @"shadowbanStatus";
