#import "KeychainStore.h"
#import <Security/Security.h>

@implementation AMKeychainStore

+ (NSString *)serviceName {
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier ?: @"unknown-host";
    return [NSString stringWithFormat:@"%@.AffiliateMenu.sessionid", bundleID];
}

+ (NSString *)accountNameForProfileIndex:(NSInteger)profileIndex {
    return [NSString stringWithFormat:@"profile.%ld", (long)profileIndex];
}

+ (NSMutableDictionary *)baseQueryForProfileIndex:(NSInteger)profileIndex {
    return [@{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: [self serviceName],
        (__bridge id)kSecAttrAccount: [self accountNameForProfileIndex:profileIndex]
    } mutableCopy];
}

+ (nullable NSString *)sessionIDForProfileIndex:(NSInteger)profileIndex {
    NSMutableDictionary *query = [self baseQueryForProfileIndex:profileIndex];
    query[(__bridge id)kSecReturnData] = @YES;
    query[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;

    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || !result) return nil;
    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

+ (BOOL)setSessionID:(NSString *)sessionID forProfileIndex:(NSInteger)profileIndex error:(NSError **)error {
    NSData *data = [sessionID dataUsingEncoding:NSUTF8StringEncoding] ?: [NSData data];
    NSMutableDictionary *query = [self baseQueryForProfileIndex:profileIndex];
    NSDictionary *attributes = @{(__bridge id)kSecValueData: data};
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)query, (__bridge CFDictionaryRef)attributes);
    if (status == errSecItemNotFound) {
        query[(__bridge id)kSecValueData] = data;
        query[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;
        status = SecItemAdd((__bridge CFDictionaryRef)query, NULL);
    }
    if (status != errSecSuccess && error) {
        *error = [NSError errorWithDomain:NSOSStatusErrorDomain code:status userInfo:nil];
    }
    return status == errSecSuccess;
}

+ (BOOL)deleteSessionIDForProfileIndex:(NSInteger)profileIndex error:(NSError **)error {
    NSMutableDictionary *query = [self baseQueryForProfileIndex:profileIndex];
    OSStatus status = SecItemDelete((__bridge CFDictionaryRef)query);
    if (status == errSecItemNotFound) status = errSecSuccess;
    if (status != errSecSuccess && error) {
        *error = [NSError errorWithDomain:NSOSStatusErrorDomain code:status userInfo:nil];
    }
    return status == errSecSuccess;
}

@end
