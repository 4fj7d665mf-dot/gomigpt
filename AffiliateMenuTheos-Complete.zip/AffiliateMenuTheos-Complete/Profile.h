#import <Foundation/Foundation.h>
#import "UAPresetManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface AMProfile : NSObject <NSCopying>
@property(nonatomic, assign) NSInteger index;
@property(nonatomic, copy) NSString *profileName;
@property(nonatomic, assign) AMUAPreset selectedUAPreset;
@property(nonatomic, copy) NSString *customUserAgent;
@end

NS_ASSUME_NONNULL_END
