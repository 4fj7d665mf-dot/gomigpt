#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, AMShadowbanStatus) {
    AMShadowbanStatusUnknown = 0,
    AMShadowbanStatusHealthy = 1,
    AMShadowbanStatusWarning = 2,
    AMShadowbanStatusRestricted = 3
};

NS_ASSUME_NONNULL_BEGIN

@interface AMShadowbanMonitor : NSObject
+ (instancetype)sharedInstance;
@property(nonatomic, assign) NSInteger profileIndex;
- (void)start;
- (void)checkNow;
- (AMShadowbanStatus)statusForProfileIndex:(NSInteger)profileIndex;
- (nullable NSDate *)lastCheckedDateForProfileIndex:(NSInteger)profileIndex;
- (NSString *)summaryForProfileIndex:(NSInteger)profileIndex;
@end

NS_ASSUME_NONNULL_END
