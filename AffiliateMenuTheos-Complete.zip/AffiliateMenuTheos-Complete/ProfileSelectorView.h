#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class AMProfileSelectorView;
@protocol AMProfileSelectorViewDelegate <NSObject>
- (void)profileSelectorView:(AMProfileSelectorView *)selector didSelectProfileIndex:(NSInteger)index;
@end

@interface AMProfileSelectorView : UIView
@property(nonatomic, weak, nullable) id<AMProfileSelectorViewDelegate> delegate;
@property(nonatomic, assign) NSInteger selectedIndex;
@end

NS_ASSUME_NONNULL_END
