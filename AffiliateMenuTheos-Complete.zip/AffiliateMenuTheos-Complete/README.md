# AffiliateMenuTheos

Standalone Theos dylib menu for an owned/self-developed iOS app. The UI direction is based on the floating dark-panel style of xelahot/iOS-Mod-Menu-Base, while bootstrap, scene/window resolution, profile persistence, Keychain, navigation and resizing are implemented without Logos or Substrate.

## Build target

- iOS 14.0+
- arm64 / arm64e
- Theos library (`AffiliateMenu.dylib`)
- UIKit / Foundation / Security / QuartzCore
- No `%hook`, `%ctor`, `Tweak.xm`
- No CydiaSubstrate / MobileSubstrate / SubstrateLoader / ElleKit / libhooker link dependency
- `UIApplication.keyWindow` is not used

## Source layout

- `Bootstrap.*` constructor + launch/active retries on main thread
- `WindowResolver.*` `connectedScenes` / `UIWindowScene.windows`
- `Menu.*` main UI
- `MenuNavigationController.*` subpage stack + top-left back button
- `MenuResizeController.*` 2-axis resize + menu move + persisted frame
- `Profile.*`, `ProfileManager.*` Profiles 1-10
- `KeychainStore.*` per-profile sessionid storage
- `UAPresetManager.*`, `UAPresetView.*` UA presets/custom popup
- `ProfileSelectorView.*` 5x2 profile selector
- `AccountSwitchManager.*` account-switch request/result contract
- `AccountSwitchLogger.*`, `AccountSwitchLogView.*` account-switch-only log
- `ShadowbanMonitor.*`, `AccountStatusView.*` green/yellow/red status checks
- `IntegrationContract.*` host-app notification contract

## Target bundle id

Set `AMTargetBundleID` in `TargetConfig.h`. Empty string allows any host process where the dylib is loaded.

## Profile data

Each Profile 1-10 stores independently:

- profileName: NSUserDefaults
- selectedUAPreset: NSUserDefaults
- customUserAgent: NSUserDefaults
- sessionid: Keychain

## payload.zip

GitHub Actions requires a repository-root `payload.zip` with:

    Payload/YourApp.app/...

Helper:

    ./scripts/make_payload_zip.sh /path/to/YourApp.app

It also accepts an `.ipa`/`.zip` that already contains `Payload/*.app`.

## GitHub Actions

`.github/workflows/build.yml` performs:

1. checkout (Git LFS enabled)
2. `payload.zip` validation + unzip + `Payload/*.app` check
3. source audit for Logos/keyWindow/banned dependencies
4. Theos setup
5. dylib build
6. arm64 + arm64e universal slice verification
7. `otool -L`
8. banned dependency failure check
9. artifact upload without renaming the built dylib

## Host app integration

The menu cannot know your app's private authentication/session implementation by itself. It sends an in-process notification request with the selected profile/session/UA. Your owned app applies it and posts the corresponding result notification. See `examples/HostIntegrationExample.mm` for the contract.

The account-switch log never prints the raw sessionid.
