#import "ShadowbanMonitor.h"
#import <UIKit/UIKit.h>
#import "IntegrationContract.h"
#import "Profile.h"
#import "ProfileManager.h"
#import "UAPresetManager.h"

@implementation AMShadowbanMonitor {
    NSTimer *_timer;
    NSString *_activeToken;
    NSMutableDictionary<NSNumber *, NSNumber *> *_statuses;
    NSMutableDictionary<NSNumber *, NSDate *> *_dates;
    NSMutableDictionary<NSNumber *, NSString *> *_summaries;
    BOOL _started;
}

+ (instancetype)sharedInstance {
    static AMShadowbanMonitor *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [AMShadowbanMonitor new]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _profileIndex = 1;
        _statuses = [NSMutableDictionary dictionary];
        _dates = [NSMutableDictionary dictionary];
        _summaries = [NSMutableDictionary dictionary];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(handleResult:) name:AMShadowbanCheckResultNotification object:nil];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(appActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(appBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    }
    return self;
}

- (void)start {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->_started) self->_started = YES;
        [self restartTimer];
        [self checkNow];
    });
}

- (void)setProfileIndex:(NSInteger)profileIndex {
    _profileIndex = MAX(1, MIN(10, profileIndex));
    if (_started) [self checkNow];
}

- (void)restartTimer {
    [_timer invalidate];
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    _timer = [NSTimer scheduledTimerWithTimeInterval:20.0 target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];
}

- (void)timerFired:(NSTimer *)timer {
    (void)timer;
    [self checkNow];
}

- (void)appActive:(NSNotification *)note {
    (void)note;
    if (!_started) return;
    [self restartTimer];
    [self checkNow];
}

- (void)appBackground:(NSNotification *)note {
    (void)note;
    [_timer invalidate];
    _timer = nil;
    _activeToken = nil;
}

- (void)checkNow {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self checkNow]; });
        return;
    }
    if (!_started || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;

    NSInteger index = self.profileIndex;
    AMProfile *profile = [AMProfileManager.sharedInstance profileForIndex:index];
    NSString *sessionID = [AMProfileManager.sharedInstance sessionIDForProfileIndex:index];
    if (sessionID.length == 0) {
        [self updateStatus:AMShadowbanStatusWarning summary:@"sessionid 未設定" profileIndex:index];
        return;
    }

    _activeToken = NSUUID.UUID.UUIDString;
    NSString *ua = [AMUAPresetManager isCustomPreset:profile.selectedUAPreset] ? profile.customUserAgent : [AMUAPresetManager userAgentForPreset:profile.selectedUAPreset];
    NSDictionary *info = @{
        AMIntegrationTokenKey:_activeToken,
        AMIntegrationProfileIndexKey:@(index),
        AMIntegrationSessionIDKey:sessionID,
        AMIntegrationUserAgentKey:ua ?: @""
    };
    [NSNotificationCenter.defaultCenter postNotificationName:AMShadowbanCheckRequestNotification object:self userInfo:info];

    NSString *token = [_activeToken copy];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (![self->_activeToken isEqualToString:token]) return;
        self->_activeToken = nil;
        [self updateStatus:AMShadowbanStatusWarning summary:@"チェック応答なし" profileIndex:index];
    });
}

- (void)handleResult:(NSNotification *)notification {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSDictionary *info = notification.userInfo ?: @{};
        NSString *token = info[AMIntegrationTokenKey];
        if (!token || ![token isEqualToString:self->_activeToken]) return;
        NSInteger index = [info[AMIntegrationProfileIndexKey] integerValue];
        AMShadowbanStatus status = (AMShadowbanStatus)[info[AMIntegrationShadowbanStatusKey] integerValue];
        if (status < AMShadowbanStatusHealthy || status > AMShadowbanStatusRestricted) status = AMShadowbanStatusWarning;
        NSString *summary = info[AMIntegrationMessageKey] ?: @"状態更新";
        self->_activeToken = nil;
        [self updateStatus:status summary:summary profileIndex:index];
    });
}

- (void)updateStatus:(AMShadowbanStatus)status summary:(NSString *)summary profileIndex:(NSInteger)profileIndex {
    NSNumber *key = @(profileIndex);
    _statuses[key] = @(status);
    _dates[key] = NSDate.date;
    _summaries[key] = summary ?: @"";
    [NSNotificationCenter.defaultCenter postNotificationName:AMShadowbanStatusDidChangeNotification object:self userInfo:@{AMIntegrationProfileIndexKey:key}];
}

- (AMShadowbanStatus)statusForProfileIndex:(NSInteger)profileIndex {
    return (AMShadowbanStatus)[_statuses[@(profileIndex)] integerValue];
}

- (nullable NSDate *)lastCheckedDateForProfileIndex:(NSInteger)profileIndex {
    return _dates[@(profileIndex)];
}

- (NSString *)summaryForProfileIndex:(NSInteger)profileIndex {
    return _summaries[@(profileIndex)] ?: @"未チェック";
}

@end
