#import "AccountStatusView.h"
#import "IntegrationContract.h"
#import "ShadowbanMonitor.h"

@implementation AMAccountStatusView {
    UILabel *_dotLabel;
    UILabel *_statusLabel;
    UILabel *_detailLabel;
    NSDateFormatter *_timeFormatter;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) [self buildUI];
    return self;
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)buildUI {
    _timeFormatter = [NSDateFormatter new];
    _timeFormatter.dateFormat = @"HH:mm:ss";

    _dotLabel = [UILabel new];
    _dotLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    _dotLabel.text = @"●";
    _dotLabel.translatesAutoresizingMaskIntoConstraints = NO;

    _statusLabel = [UILabel new];
    _statusLabel.textColor = UIColor.whiteColor;
    _statusLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    _statusLabel.translatesAutoresizingMaskIntoConstraints = NO;

    _detailLabel = [UILabel new];
    _detailLabel.textColor = [UIColor colorWithWhite:0.62 alpha:1];
    _detailLabel.font = [UIFont systemFontOfSize:11];
    _detailLabel.numberOfLines = 2;
    _detailLabel.translatesAutoresizingMaskIntoConstraints = NO;

    [self addSubview:_dotLabel];
    [self addSubview:_statusLabel];
    [self addSubview:_detailLabel];
    [NSLayoutConstraint activateConstraints:@[
        [_dotLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_dotLabel.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_dotLabel.widthAnchor constraintEqualToConstant:26],
        [_statusLabel.leadingAnchor constraintEqualToAnchor:_dotLabel.trailingAnchor constant:4],
        [_statusLabel.centerYAnchor constraintEqualToAnchor:_dotLabel.centerYAnchor],
        [_statusLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_detailLabel.leadingAnchor constraintEqualToAnchor:_statusLabel.leadingAnchor],
        [_detailLabel.topAnchor constraintEqualToAnchor:_statusLabel.bottomAnchor constant:2],
        [_detailLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_detailLabel.bottomAnchor constraintEqualToAnchor:self.bottomAnchor]
    ]];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(statusChanged:) name:AMShadowbanStatusDidChangeNotification object:nil];
    [self reloadStatus];
}

- (void)setProfileIndex:(NSInteger)profileIndex {
    _profileIndex = profileIndex;
    [self reloadStatus];
}

- (void)statusChanged:(NSNotification *)notification {
    if ([notification.userInfo[AMIntegrationProfileIndexKey] integerValue] == self.profileIndex) [self reloadStatus];
}

- (void)reloadStatus {
    AMShadowbanMonitor *monitor = AMShadowbanMonitor.sharedInstance;
    AMShadowbanStatus status = [monitor statusForProfileIndex:self.profileIndex];
    NSString *title;
    UIColor *color;
    switch (status) {
        case AMShadowbanStatusHealthy: title = @"正常"; color = UIColor.systemGreenColor; break;
        case AMShadowbanStatusWarning: title = @"要確認"; color = UIColor.systemYellowColor; break;
        case AMShadowbanStatusRestricted: title = @"制限の可能性"; color = UIColor.systemRedColor; break;
        default: title = @"未チェック"; color = UIColor.systemGrayColor; break;
    }
    _dotLabel.textColor = color;
    _statusLabel.text = title;
    NSDate *date = [monitor lastCheckedDateForProfileIndex:self.profileIndex];
    NSString *time = date ? [_timeFormatter stringFromDate:date] : @"--:--:--";
    _detailLabel.text = [NSString stringWithFormat:@"%@  ·  最終チェック %@", [monitor summaryForProfileIndex:self.profileIndex], time];
}

@end
