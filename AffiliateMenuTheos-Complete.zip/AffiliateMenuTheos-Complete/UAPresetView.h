#import <UIKit/UIKit.h>
#import "UAPresetManager.h"

NS_ASSUME_NONNULL_BEGIN

@class AMUAPresetView;
@protocol AMUAPresetViewDelegate <NSObject>
- (void)uaPresetView:(AMUAPresetView *)view didSelectPreset:(AMUAPreset)preset;
@end

@interface AMUAPresetView : UIView
@property(nonatomic, weak, nullable) id<AMUAPresetViewDelegate> delegate;
@property(nonatomic, assign) AMUAPreset selectedPreset;
- (void)presentFromView:(UIView *)sourceView inContainer:(UIView *)container;
- (void)dismiss;
@end

NS_ASSUME_NONNULL_END
