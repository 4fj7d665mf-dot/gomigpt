#import "MenuNavigationController.h"
#import "MenuLayoutMetrics.h"

@implementation AMMenuNavigationController {
    UIView *_rootView;
    UIView *_headerView;
    UIView *_contentHost;
    UIButton *_backButton;
    UIButton *_closeButton;
    UILabel *_titleLabel;
    NSMutableArray<UIView *> *_views;
    NSMutableArray<NSString *> *_titles;
}

- (instancetype)init {
    self = [super init];
    if (self) [self buildUI];
    return self;
}

- (UIView *)rootView { return _rootView; }
- (UIView *)headerView { return _headerView; }
- (UIButton *)closeButton { return _closeButton; }

- (void)buildUI {
    _views = [NSMutableArray array];
    _titles = [NSMutableArray array];
    _rootView = [UIView new];
    _rootView.backgroundColor = [UIColor colorWithWhite:0.055 alpha:0.96];
    _rootView.layer.cornerRadius = 18;
    _rootView.layer.borderWidth = 1;
    _rootView.layer.borderColor = [UIColor colorWithWhite:0.30 alpha:0.9].CGColor;
    _rootView.clipsToBounds = YES;

    _headerView = [UIView new];
    _headerView.backgroundColor = [UIColor colorWithWhite:0.085 alpha:1.0];
    _headerView.translatesAutoresizingMaskIntoConstraints = NO;
    [_rootView addSubview:_headerView];

    _backButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_backButton setTitle:@"◀" forState:UIControlStateNormal];
    [_backButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    _backButton.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightBold];
    _backButton.translatesAutoresizingMaskIntoConstraints = NO;
    [_backButton addTarget:self action:@selector(backTapped) forControlEvents:UIControlEventTouchUpInside];
    [_headerView addSubview:_backButton];

    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    UIImage *xmark = [UIImage systemImageNamed:@"xmark"];
    [_closeButton setImage:xmark forState:UIControlStateNormal];
    _closeButton.tintColor = UIColor.whiteColor;
    _closeButton.translatesAutoresizingMaskIntoConstraints = NO;
    [_headerView addSubview:_closeButton];

    _titleLabel = [UILabel new];
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [_headerView addSubview:_titleLabel];

    _contentHost = [UIView new];
    _contentHost.translatesAutoresizingMaskIntoConstraints = NO;
    [_rootView addSubview:_contentHost];

    [NSLayoutConstraint activateConstraints:@[
        [_headerView.topAnchor constraintEqualToAnchor:_rootView.topAnchor],
        [_headerView.leadingAnchor constraintEqualToAnchor:_rootView.leadingAnchor],
        [_headerView.trailingAnchor constraintEqualToAnchor:_rootView.trailingAnchor],
        [_headerView.heightAnchor constraintEqualToConstant:AMMenuHeaderHeight],
        [_backButton.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor constant:4],
        [_backButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_backButton.widthAnchor constraintEqualToConstant:44],
        [_backButton.heightAnchor constraintEqualToConstant:44],
        [_closeButton.trailingAnchor constraintEqualToAnchor:_headerView.trailingAnchor constant:-4],
        [_closeButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_closeButton.widthAnchor constraintEqualToConstant:44],
        [_closeButton.heightAnchor constraintEqualToConstant:44],
        [_titleLabel.leadingAnchor constraintEqualToAnchor:_backButton.trailingAnchor constant:4],
        [_titleLabel.trailingAnchor constraintEqualToAnchor:_closeButton.leadingAnchor constant:-4],
        [_titleLabel.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_contentHost.topAnchor constraintEqualToAnchor:_headerView.bottomAnchor],
        [_contentHost.leadingAnchor constraintEqualToAnchor:_rootView.leadingAnchor],
        [_contentHost.trailingAnchor constraintEqualToAnchor:_rootView.trailingAnchor],
        [_contentHost.bottomAnchor constraintEqualToAnchor:_rootView.bottomAnchor]
    ]];
    [self updateHeader];
}

- (void)setRootPage:(UIView *)view title:(NSString *)title {
    for (UIView *existing in _views) [existing removeFromSuperview];
    [_views removeAllObjects];
    [_titles removeAllObjects];
    [_views addObject:view];
    [_titles addObject:title ?: @""];
    [self showTopView];
}

- (void)pushPage:(UIView *)view title:(NSString *)title {
    [_views addObject:view];
    [_titles addObject:title ?: @""];
    [self showTopView];
}

- (void)popPage {
    if (_views.count <= 1) return;
    UIView *top = _views.lastObject;
    [top removeFromSuperview];
    [_views removeLastObject];
    [_titles removeLastObject];
    [self showTopView];
}

- (void)backTapped { [self popPage]; }

- (void)showTopView {
    for (UIView *view in _contentHost.subviews) [view removeFromSuperview];
    UIView *view = _views.lastObject;
    if (view) {
        view.translatesAutoresizingMaskIntoConstraints = NO;
        [_contentHost addSubview:view];
        [NSLayoutConstraint activateConstraints:@[
            [view.topAnchor constraintEqualToAnchor:_contentHost.topAnchor],
            [view.bottomAnchor constraintEqualToAnchor:_contentHost.bottomAnchor],
            [view.leadingAnchor constraintEqualToAnchor:_contentHost.leadingAnchor],
            [view.trailingAnchor constraintEqualToAnchor:_contentHost.trailingAnchor]
        ]];
    }
    [self updateHeader];
}

- (void)updateHeader {
    _backButton.hidden = _views.count <= 1;
    _titleLabel.text = _titles.lastObject ?: @"Affiliate Menu";
}

@end
