#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, AMUAPreset) {
    AMUAPresetSafariIOS = 0,
    AMUAPresetSafariIPad,
    AMUAPresetChromeIPhone,
    AMUAPresetFirefoxIPhone,
    AMUAPresetEdgeIPhone,
    AMUAPresetCustom
};

NS_ASSUME_NONNULL_BEGIN

@interface AMUAPresetManager : NSObject
+ (NSArray<NSNumber *> *)allPresets;
+ (NSString *)titleForPreset:(AMUAPreset)preset;
+ (NSString *)userAgentForPreset:(AMUAPreset)preset;
+ (BOOL)isCustomPreset:(AMUAPreset)preset;
@end

NS_ASSUME_NONNULL_END
