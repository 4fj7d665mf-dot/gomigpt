#import "UAPresetView.h"

static const CGFloat AMUAPresetPopupHeight = 292.0;
static const CGFloat AMUAPresetPopupInset = 10.0;
static const CGFloat AMUAPresetPopupGap = 7.0;

@implementation AMUAPresetView {
    UIStackView *_stack;
    __weak UIView *_sourceView;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) [self buildUI];
    return self;
}

- (void)buildUI {
    self.backgroundColor = [UIColor colorWithWhite:0.055 alpha:0.97];
    self.layer.cornerRadius = 16.0;
    self.layer.borderWidth = 1.0;
    self.layer.borderColor = [UIColor colorWithWhite:0.28 alpha:0.8].CGColor;
    self.clipsToBounds = YES;

    _stack = [UIStackView new];
    _stack.axis = UILayoutConstraintAxisVertical;
    _stack.spacing = 0;
    _stack.distribution = UIStackViewDistributionFillEqually;
    _stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_stack];

    [NSLayoutConstraint activateConstraints:@[
        [_stack.topAnchor constraintEqualToAnchor:self.topAnchor constant:7],
        [_stack.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-7],
        [_stack.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:7],
        [_stack.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-7]
    ]];

    for (NSNumber *value in AMUAPresetManager.allPresets) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = value.integerValue;
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        button.contentEdgeInsets = UIEdgeInsetsMake(0, 12, 0, 12);
        button.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
        [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        [button addTarget:self action:@selector(rowTapped:) forControlEvents:UIControlEventTouchUpInside];
        [_stack addArrangedSubview:button];
    }

    [self refreshTitles];
}

- (void)setSelectedPreset:(AMUAPreset)selectedPreset {
    _selectedPreset = selectedPreset;
    [self refreshTitles];
}

- (void)refreshTitles {
    for (UIView *view in _stack.arrangedSubviews) {
        UIButton *button = (UIButton *)view;
        AMUAPreset preset = (AMUAPreset)button.tag;
        NSString *mark = preset == self.selectedPreset ? @"✓  " : @"    ";
        [button setTitle:[mark stringByAppendingString:[AMUAPresetManager titleForPreset:preset]]
                forState:UIControlStateNormal];
    }
}

- (void)presentFromView:(UIView *)sourceView inContainer:(UIView *)container {
    [self removeFromSuperview];
    _sourceView = sourceView;
    self.translatesAutoresizingMaskIntoConstraints = YES;

    CGRect source = [sourceView convertRect:sourceView.bounds toView:container];
    CGFloat containerWidth = CGRectGetWidth(container.bounds);
    CGFloat containerHeight = CGRectGetHeight(container.bounds);

    CGFloat width = MAX(180.0, MIN(CGRectGetWidth(source) - 20.0, containerWidth - AMUAPresetPopupInset * 2.0));
    CGFloat x = CGRectGetMinX(source) + 10.0;
    x = MIN(MAX(x, AMUAPresetPopupInset), MAX(AMUAPresetPopupInset, containerWidth - AMUAPresetPopupInset - width));

    CGFloat belowY = CGRectGetMaxY(source) + AMUAPresetPopupGap;
    CGFloat aboveY = CGRectGetMinY(source) - AMUAPresetPopupGap - AMUAPresetPopupHeight;
    CGFloat y = belowY;
    if (belowY + AMUAPresetPopupHeight > containerHeight - AMUAPresetPopupInset && aboveY >= AMUAPresetPopupInset) {
        y = aboveY;
    }
    y = MIN(MAX(y, AMUAPresetPopupInset), MAX(AMUAPresetPopupInset, containerHeight - AMUAPresetPopupInset - AMUAPresetPopupHeight));

    self.frame = CGRectIntegral(CGRectMake(x, y, width, AMUAPresetPopupHeight));
    self.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [container addSubview:self];
    [container bringSubviewToFront:self];
}

- (void)dismiss {
    [self removeFromSuperview];
    _sourceView = nil;
}

- (void)rowTapped:(UIButton *)sender {
    self.selectedPreset = (AMUAPreset)sender.tag;
    [self.delegate uaPresetView:self didSelectPreset:self.selectedPreset];
    [self dismiss];
}

@end
