#import <Foundation/Foundation.h>
@class AMProfile;

NS_ASSUME_NONNULL_BEGIN

@interface AMProfileManager : NSObject
+ (instancetype)sharedInstance;
@property(nonatomic, assign) NSInteger selectedProfileIndex;
- (AMProfile *)profileForIndex:(NSInteger)index;
- (BOOL)saveProfile:(AMProfile *)profile sessionID:(NSString *)sessionID error:(NSError * _Nullable * _Nullable)error;
- (NSString *)sessionIDForProfileIndex:(NSInteger)index;
- (void)resetProfileAtIndex:(NSInteger)index;
@end

NS_ASSUME_NONNULL_END
