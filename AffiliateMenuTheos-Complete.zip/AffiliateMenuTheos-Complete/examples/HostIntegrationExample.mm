// Example only. Do not add this file to AffiliateMenu_FILES unless your own app
// intentionally uses this notification contract.
#import <Foundation/Foundation.h>
#import "../IntegrationContract.h"
#import "../ShadowbanMonitor.h"

@interface AMHostIntegrationExample : NSObject
@end

@implementation AMHostIntegrationExample

+ (void)installExampleObservers {
    NSNotificationCenter *center = NSNotificationCenter.defaultCenter;

    [center addObserverForName:AMAccountSwitchRequestNotification
                        object:nil
                         queue:NSOperationQueue.mainQueue
                    usingBlock:^(NSNotification *note) {
        NSString *token = note.userInfo[AMIntegrationTokenKey];
        NSString *sessionID = note.userInfo[AMIntegrationSessionIDKey];

        // Replace this block with your own app's legitimate session/auth update.
        BOOL success = (sessionID.length > 0);
        NSDictionary *result = @{
            AMIntegrationTokenKey: token ?: @"",
            AMIntegrationProfileIndexKey: note.userInfo[AMIntegrationProfileIndexKey] ?: @1,
            AMIntegrationSuccessKey: @(success),
            AMIntegrationMessageKey: success ? @"Example host accepted session" : @"Empty session"
        };
        [center postNotificationName:AMAccountSwitchResultNotification object:nil userInfo:result];
    }];

    [center addObserverForName:AMShadowbanCheckRequestNotification
                        object:nil
                         queue:NSOperationQueue.mainQueue
                    usingBlock:^(NSNotification *note) {
        NSString *token = note.userInfo[AMIntegrationTokenKey];

        // Replace with a diagnostic owned by your app.
        NSDictionary *result = @{
            AMIntegrationTokenKey: token ?: @"",
            AMIntegrationProfileIndexKey: note.userInfo[AMIntegrationProfileIndexKey] ?: @1,
            AMIntegrationShadowbanStatusKey: @(AMShadowbanStatusHealthy),
            AMIntegrationMessageKey: @"Example diagnostic OK"
        };
        [center postNotificationName:AMShadowbanCheckResultNotification object:nil userInfo:result];
    }];
}

@end
