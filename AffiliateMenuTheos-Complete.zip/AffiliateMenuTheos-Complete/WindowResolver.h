#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMWindowResolver : NSObject
+ (nullable UIWindow *)bestApplicationWindow;
@end

NS_ASSUME_NONNULL_END
