#!/bin/bash
set -euo pipefail

DYLIB="${1:-}"
if [[ -z "$DYLIB" || ! -f "$DYLIB" ]]; then
  echo "usage: $0 path/to/AffiliateMenu.dylib" >&2
  exit 2
fi

BANNED='CydiaSubstrate|MobileSubstrate|SubstrateLoader|ElleKit|libhooker'

echo "== Architectures =="
lipo -archs "$DYLIB"
ARCHS="$(lipo -archs "$DYLIB")"
grep -qw arm64 <<<"$ARCHS" || { echo "arm64 slice missing" >&2; exit 1; }
grep -qw arm64e <<<"$ARCHS" || { echo "arm64e slice missing" >&2; exit 1; }

echo "== Linked libraries =="
otool -L "$DYLIB"
if otool -L "$DYLIB" | grep -Eiq "$BANNED"; then
  echo "Banned hook/substrate dependency detected" >&2
  exit 1
fi

echo "Dependency check passed."
