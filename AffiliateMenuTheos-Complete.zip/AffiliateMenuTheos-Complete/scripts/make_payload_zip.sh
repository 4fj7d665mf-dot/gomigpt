#!/usr/bin/env bash
set -euo pipefail

INPUT="${1:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTPUT="$ROOT/payload.zip"

if [[ -z "$INPUT" ]]; then
  echo "usage: $0 /path/to/App.app|App.ipa|payload.zip" >&2
  exit 2
fi

INPUT="$(cd "$(dirname "$INPUT")" && pwd)/$(basename "$INPUT")"

rm -f "$OUTPUT"

if [[ -d "$INPUT" && "$INPUT" == *.app ]]; then
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  mkdir -p "$TMP/Payload"
  cp -R "$INPUT" "$TMP/Payload/"
  (cd "$TMP" && /usr/bin/zip -qry "$OUTPUT" Payload)
elif [[ -f "$INPUT" ]]; then
  if ! unzip -l "$INPUT" 2>/dev/null | grep -Eq 'Payload/[^/]+\.app/'; then
    echo "ERROR: archive does not contain Payload/*.app" >&2
    exit 1
  fi
  cp "$INPUT" "$OUTPUT"
else
  echo "ERROR: input not found: $INPUT" >&2
  exit 1
fi

echo "Created: $OUTPUT"
unzip -l "$OUTPUT" | grep -E 'Payload/[^/]+\.app/' | head
