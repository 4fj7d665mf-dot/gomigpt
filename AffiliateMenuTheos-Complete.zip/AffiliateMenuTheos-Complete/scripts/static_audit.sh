#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail=0

if grep -RInE --include='*.m' --include='*.mm' --include='*.xm' --include='*.x' '%hook|%ctor|%init|%orig' .; then
  echo "ERROR: Logos directive found"
  fail=1
fi

if grep -RInE --include='*.m' --include='*.mm' --include='*.h' 'UIApplication[^\n]*keyWindow|\.keyWindow' .; then
  echo "ERROR: UIApplication.keyWindow/keyWindow usage found"
  fail=1
fi

if grep -InE 'CydiaSubstrate|MobileSubstrate|SubstrateLoader|ElleKit|libhooker' Makefile; then
  echo "ERROR: banned hook/substrate dependency referenced in Makefile"
  fail=1
fi

if find . -maxdepth 2 -type f \( -name 'Tweak.xm' -o -name '*.xm' \) -print | grep -q .; then
  echo "ERROR: Logos/Tweak.xm source present"
  fail=1
fi

if [[ "$fail" -ne 0 ]]; then
  exit 1
fi

echo "Static audit passed."
