#import "AccountSwitchLogView.h"
#import "AccountSwitchLogger.h"
#import "IntegrationContract.h"

@implementation AMAccountSwitchLogView {
    UITextView *_textView;
    UIButton *_clearButton;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) [self buildUI];
    return self;
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)buildUI {
    _textView = [UITextView new];
    _textView.editable = NO;
    _textView.selectable = YES;
    _textView.backgroundColor = [UIColor colorWithWhite:0.075 alpha:1.0];
    _textView.textColor = UIColor.whiteColor;
    _textView.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    _textView.layer.cornerRadius = 10;
    _textView.layer.borderWidth = 1;
    _textView.layer.borderColor = [UIColor colorWithWhite:0.28 alpha:0.9].CGColor;
    _textView.translatesAutoresizingMaskIntoConstraints = NO;

    _clearButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_clearButton setTitle:@"Clear Log" forState:UIControlStateNormal];
    [_clearButton setTitleColor:[UIColor colorWithWhite:0.85 alpha:1] forState:UIControlStateNormal];
    _clearButton.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    _clearButton.translatesAutoresizingMaskIntoConstraints = NO;
    [_clearButton addTarget:self action:@selector(clearTapped) forControlEvents:UIControlEventTouchUpInside];

    [self addSubview:_textView];
    [self addSubview:_clearButton];
    [NSLayoutConstraint activateConstraints:@[
        [_textView.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_textView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_textView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_textView.heightAnchor constraintGreaterThanOrEqualToConstant:150],
        [_clearButton.topAnchor constraintEqualToAnchor:_textView.bottomAnchor constant:5],
        [_clearButton.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_clearButton.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
        [_clearButton.heightAnchor constraintEqualToConstant:30]
    ]];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(logChanged:) name:AMAccountSwitchLogDidChangeNotification object:nil];
}

- (void)setProfileIndex:(NSInteger)profileIndex {
    _profileIndex = profileIndex;
    [self reloadLog];
}

- (void)logChanged:(NSNotification *)notification {
    if ([notification.userInfo[AMIntegrationProfileIndexKey] integerValue] == self.profileIndex) [self reloadLog];
}

- (void)reloadLog {
    NSArray<NSString *> *entries = [AMAccountSwitchLogger.sharedInstance entriesForProfileIndex:self.profileIndex];
    _textView.text = [entries componentsJoinedByString:@"\n"];
    if (_textView.text.length) {
        NSRange bottom = NSMakeRange(_textView.text.length - 1, 1);
        [_textView scrollRangeToVisible:bottom];
    }
}

- (void)clearTapped {
    [AMAccountSwitchLogger.sharedInstance clearProfileIndex:self.profileIndex];
}

@end
