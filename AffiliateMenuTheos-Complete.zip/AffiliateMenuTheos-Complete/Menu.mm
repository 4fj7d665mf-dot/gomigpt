#import "Menu.h"
#import "AccountStatusView.h"
#import "AccountSwitchLogView.h"
#import "AccountSwitchManager.h"
#import "MenuLayoutMetrics.h"
#import "MenuNavigationController.h"
#import "MenuResizeController.h"
#import "Profile.h"
#import "ProfileManager.h"
#import "ProfileSelectorView.h"
#import "ShadowbanMonitor.h"
#import "UAPresetManager.h"
#import "UAPresetView.h"


@interface AMGeometryObserverView : UIView
@property(nonatomic, copy, nullable) void (^layoutCallback)(void);
@end

@implementation AMGeometryObserverView
- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.layoutCallback) self.layoutCallback();
}
@end

@interface AMMenu () <AMProfileSelectorViewDelegate, AMUAPresetViewDelegate, UITextViewDelegate>
@end

@implementation AMMenu {
    __weak UIWindow *_hostWindow;
    UIButton *_floatingButton;
    UIView *_panel;
    AMMenuNavigationController *_navigation;
    AMMenuResizeController *_resizeController;
    AMGeometryObserverView *_geometryObserver;

    AMProfileSelectorView *_profileSelector;
    UITextField *_profileNameField;
    UITextField *_sessionField;
    UIButton *_presetButton;
    UITextView *_customUAView;
    AMUAPresetView *_presetPopup;
    AMAccountStatusView *_statusView;
    UILabel *_saveStatusLabel;

    UIView *_accountPage;
    UILabel *_accountProfileLabel;
    UILabel *_accountResultLabel;
    AMAccountSwitchLogView *_accountLogView;

    AMUAPreset _currentPreset;
    NSString *_currentCustomUA;
    CGPoint _floatingDragStart;
    CGRect _floatingStartFrame;
}

+ (instancetype)sharedInstance {
    static AMMenu *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [AMMenu new]; });
    return instance;
}

- (void)ensureInstalledInWindow:(UIWindow *)window {
    NSAssert(NSThread.isMainThread, @"Menu UI must be installed on main thread");
    if (!window) return;
    if (!_floatingButton) [self buildMenuForWindow:window];
    _hostWindow = window;
    if (_geometryObserver.superview != window) {
        [_geometryObserver removeFromSuperview];
        _geometryObserver.frame = window.bounds;
        _geometryObserver.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [window insertSubview:_geometryObserver atIndex:0];
    }
    if (_floatingButton.superview != window) {
        [_floatingButton removeFromSuperview];
        [window addSubview:_floatingButton];
    }
    if (_panel.superview != window) {
        [_panel removeFromSuperview];
        [window addSubview:_panel];
    }
    [_resizeController updateHostWindow:window];
    [window bringSubviewToFront:_floatingButton];
    if (!_panel.hidden) [window bringSubviewToFront:_panel];
}

- (void)buildMenuForWindow:(UIWindow *)window {
    _floatingButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _floatingButton.frame = CGRectMake(18, MAX(100, CGRectGetMidY(window.bounds) - 28), 56, 56);
    _floatingButton.backgroundColor = [UIColor colorWithWhite:0.075 alpha:0.94];
    _floatingButton.layer.cornerRadius = 28;
    _floatingButton.layer.borderWidth = 1;
    _floatingButton.layer.borderColor = [UIColor colorWithWhite:0.48 alpha:0.8].CGColor;
    _floatingButton.tintColor = UIColor.whiteColor;
    [_floatingButton setImage:[UIImage systemImageNamed:@"slider.horizontal.3"] forState:UIControlStateNormal];
    [_floatingButton addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *floatPan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragFloatingButton:)];
    [_floatingButton addGestureRecognizer:floatPan];

    _geometryObserver = [AMGeometryObserverView new];
    _geometryObserver.frame = window.bounds;
    _geometryObserver.userInteractionEnabled = NO;
    _geometryObserver.backgroundColor = UIColor.clearColor;
    __weak AMMenu *weakSelf = self;
    _geometryObserver.layoutCallback = ^{
        AMMenu *strongSelf = weakSelf;
        if (!strongSelf) return;
        [strongSelf->_resizeController restoreAndClampFrame];
    };

    _navigation = [AMMenuNavigationController new];
    _panel = _navigation.rootView;
    _panel.frame = CGRectMake(0, 0, AMMenuInitialWidth, AMMenuInitialHeight);
    _panel.hidden = YES;
    [_navigation.closeButton addTarget:self action:@selector(closePanel) forControlEvents:UIControlEventTouchUpInside];

    UIView *mainPage = [self buildMainPage];
    [_navigation setRootPage:mainPage title:@"Affiliate Menu"];
    _accountPage = [self buildAccountPage];

    _resizeController = [[AMMenuResizeController alloc] initWithPanel:_panel hostWindow:window moveHandle:_navigation.headerView];
    _geometryObserver.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [window insertSubview:_geometryObserver atIndex:0];
    [window addSubview:_floatingButton];
    [window addSubview:_panel];
    [_resizeController restoreAndClampFrame];

    NSInteger selected = AMProfileManager.sharedInstance.selectedProfileIndex;
    _profileSelector.selectedIndex = selected;
    [self loadProfile:selected];
    AMShadowbanMonitor.sharedInstance.profileIndex = selected;
    [AMShadowbanMonitor.sharedInstance start];
}

- (UIView *)buildMainPage {
    UIView *page = [UIView new];
    UIScrollView *scroll = [UIScrollView new];
    scroll.alwaysBounceVertical = YES;
    scroll.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    [page addSubview:scroll];

    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 9;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:stack];

    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:page.topAnchor],
        [scroll.bottomAnchor constraintEqualToAnchor:page.bottomAnchor],
        [scroll.leadingAnchor constraintEqualToAnchor:page.leadingAnchor],
        [scroll.trailingAnchor constraintEqualToAnchor:page.trailingAnchor],
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:14],
        [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-58],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.leadingAnchor constant:16],
        [stack.trailingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.trailingAnchor constant:-16]
    ]];

    _profileSelector = [AMProfileSelectorView new];
    _profileSelector.delegate = self;
    [stack addArrangedSubview:_profileSelector];

    [stack addArrangedSubview:[self label:@"プロファイル名"]];
    _profileNameField = [self textFieldWithPlaceholder:@"Affiliate-01" secure:NO];
    [stack addArrangedSubview:_profileNameField];

    [stack addArrangedSubview:[self label:@"TikTok sessionid"]];
    _sessionField = [self textFieldWithPlaceholder:@"sessionid" secure:YES];
    _sessionField.textContentType = nil;
    [stack addArrangedSubview:_sessionField];
    UIStackView *sessionButtons = [self horizontalButtons:@[@"Paste", @"Clear"] actions:@[NSStringFromSelector(@selector(pasteSession)), NSStringFromSelector(@selector(clearSession))]];
    [stack addArrangedSubview:sessionButtons];

    [stack addArrangedSubview:[self label:@"シャドウバン状態"]];
    _statusView = [AMAccountStatusView new];
    [stack addArrangedSubview:_statusView];

    UIButton *accountButton = [self actionButton:@"アカウント切り替え / Log" selector:@selector(openAccountPage)];
    [stack addArrangedSubview:accountButton];

    [stack addArrangedSubview:[self label:@"プリセット"]];
    _presetButton = [self actionButton:@"Safari (iOS)  ▼" selector:@selector(showPresetMenu)];
    _presetButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    _presetButton.contentEdgeInsets = UIEdgeInsetsMake(0, 12, 0, 12);
    [stack addArrangedSubview:_presetButton];

    [stack addArrangedSubview:[self label:@"カスタムユーザーエージェント"]];
    _customUAView = [UITextView new];
    _customUAView.backgroundColor = [UIColor colorWithWhite:0.105 alpha:1];
    _customUAView.textColor = UIColor.whiteColor;
    _customUAView.font = [UIFont monospacedSystemFontOfSize:11.5 weight:UIFontWeightRegular];
    _customUAView.layer.cornerRadius = 10;
    _customUAView.layer.borderWidth = 1;
    _customUAView.layer.borderColor = [UIColor colorWithWhite:0.30 alpha:0.85].CGColor;
    _customUAView.delegate = self;
    [_customUAView.heightAnchor constraintEqualToConstant:118].active = YES;
    [stack addArrangedSubview:_customUAView];

    UIStackView *saveButtons = [self horizontalButtons:@[@"Save", @"Reset"] actions:@[NSStringFromSelector(@selector(saveCurrentProfile)), NSStringFromSelector(@selector(resetCurrentProfile))]];
    [stack addArrangedSubview:saveButtons];
    _saveStatusLabel = [self label:@""];
    _saveStatusLabel.font = [UIFont systemFontOfSize:11];
    [stack addArrangedSubview:_saveStatusLabel];

    return page;
}

- (UIView *)buildAccountPage {
    UIView *page = [UIView new];
    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 10;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [page addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:page.topAnchor constant:16],
        [stack.leadingAnchor constraintEqualToAnchor:page.leadingAnchor constant:16],
        [stack.trailingAnchor constraintEqualToAnchor:page.trailingAnchor constant:-16],
        [stack.bottomAnchor constraintLessThanOrEqualToAnchor:page.bottomAnchor constant:-52]
    ]];

    _accountProfileLabel = [self label:@"Profile"];
    _accountProfileLabel.textColor = UIColor.whiteColor;
    _accountProfileLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    [stack addArrangedSubview:_accountProfileLabel];

    UIButton *switchButton = [self actionButton:@"アカウント切り替え" selector:@selector(executeAccountSwitch)];
    [stack addArrangedSubview:switchButton];

    _accountResultLabel = [self label:@"保存済みのsessionidを自作アプリ側へ渡します。"];
    _accountResultLabel.numberOfLines = 2;
    [stack addArrangedSubview:_accountResultLabel];

    UILabel *logTitle = [self label:@"Account Switch Log"];
    logTitle.textColor = UIColor.whiteColor;
    logTitle.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [stack addArrangedSubview:logTitle];

    _accountLogView = [AMAccountSwitchLogView new];
    [stack addArrangedSubview:_accountLogView];
    return page;
}

- (UILabel *)label:(NSString *)text {
    UILabel *label = [UILabel new];
    label.text = text;
    label.textColor = [UIColor colorWithWhite:0.64 alpha:1];
    label.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    return label;
}

- (UITextField *)textFieldWithPlaceholder:(NSString *)placeholder secure:(BOOL)secure {
    UITextField *field = [UITextField new];
    field.placeholder = placeholder;
    field.secureTextEntry = secure;
    field.backgroundColor = [UIColor colorWithWhite:0.105 alpha:1];
    field.textColor = UIColor.whiteColor;
    field.font = [UIFont systemFontOfSize:13];
    field.layer.cornerRadius = 9;
    field.layer.borderWidth = 1;
    field.layer.borderColor = [UIColor colorWithWhite:0.30 alpha:0.85].CGColor;
    field.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 11, 1)];
    field.leftViewMode = UITextFieldViewModeAlways;
    [field.heightAnchor constraintEqualToConstant:AMMenuControlHeight].active = YES;
    return field;
}

- (UIButton *)actionButton:(NSString *)title selector:(SEL)selector {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    button.backgroundColor = [UIColor colorWithWhite:0.15 alpha:1];
    button.layer.cornerRadius = 9;
    button.layer.borderWidth = 1;
    button.layer.borderColor = [UIColor colorWithWhite:0.32 alpha:0.8].CGColor;
    [button.heightAnchor constraintEqualToConstant:AMMenuControlHeight].active = YES;
    [button addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (UIStackView *)horizontalButtons:(NSArray<NSString *> *)titles actions:(NSArray<NSString *> *)actions {
    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.spacing = 8;
    stack.distribution = UIStackViewDistributionFillEqually;
    [titles enumerateObjectsUsingBlock:^(NSString *title, NSUInteger idx, BOOL *stop) {
        (void)stop;
        SEL selector = NSSelectorFromString(actions[idx]);
        [stack addArrangedSubview:[self actionButton:title selector:selector]];
    }];
    return stack;
}

- (void)togglePanel {
    _panel.hidden = !_panel.hidden;
    if (!_panel.hidden) {
        [_resizeController restoreAndClampFrame];
        [_hostWindow bringSubviewToFront:_panel];
    }
}

- (void)closePanel { _panel.hidden = YES; [_presetPopup dismiss]; }

- (void)dragFloatingButton:(UIPanGestureRecognizer *)gesture {
    UIWindow *window = _hostWindow;
    if (!window) return;
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _floatingDragStart = [gesture locationInView:window];
        _floatingStartFrame = _floatingButton.frame;
    }
    CGPoint current = [gesture locationInView:window];
    CGRect frame = _floatingStartFrame;
    frame.origin.x += current.x - _floatingDragStart.x;
    frame.origin.y += current.y - _floatingDragStart.y;
    UIEdgeInsets safe = window.safeAreaInsets;
    frame.origin.x = MIN(MAX(frame.origin.x, safe.left + 4), CGRectGetWidth(window.bounds) - safe.right - CGRectGetWidth(frame) - 4);
    frame.origin.y = MIN(MAX(frame.origin.y, safe.top + 4), CGRectGetHeight(window.bounds) - safe.bottom - CGRectGetHeight(frame) - 4);
    _floatingButton.frame = frame;
}

- (void)profileSelectorView:(AMProfileSelectorView *)selector didSelectProfileIndex:(NSInteger)index {
    (void)selector;
    AMProfileManager.sharedInstance.selectedProfileIndex = index;
    [self loadProfile:index];
    AMShadowbanMonitor.sharedInstance.profileIndex = index;
}

- (void)loadProfile:(NSInteger)index {
    AMProfile *profile = [AMProfileManager.sharedInstance profileForIndex:index];
    _profileNameField.text = profile.profileName;
    _sessionField.text = [AMProfileManager.sharedInstance sessionIDForProfileIndex:index];
    _currentPreset = profile.selectedUAPreset;
    _currentCustomUA = profile.customUserAgent ?: @"";
    _statusView.profileIndex = index;
    _accountLogView.profileIndex = index;
    [self refreshUAUI];
    _saveStatusLabel.text = @"";
}

- (void)refreshUAUI {
    NSString *title = [NSString stringWithFormat:@"%@  ▼", [AMUAPresetManager titleForPreset:_currentPreset]];
    [_presetButton setTitle:title forState:UIControlStateNormal];
    BOOL custom = [AMUAPresetManager isCustomPreset:_currentPreset];
    _customUAView.editable = custom;
    _customUAView.alpha = custom ? 1.0 : 0.72;
    _customUAView.text = custom ? (_currentCustomUA ?: @"") : [AMUAPresetManager userAgentForPreset:_currentPreset];
}

- (void)showPresetMenu {
    if (!_presetPopup) {
        _presetPopup = [AMUAPresetView new];
        _presetPopup.delegate = self;
    }
    _presetPopup.selectedPreset = _currentPreset;
    [_presetPopup presentFromView:_presetButton inContainer:_panel];
}

- (void)uaPresetView:(AMUAPresetView *)view didSelectPreset:(AMUAPreset)preset {
    (void)view;
    if ([AMUAPresetManager isCustomPreset:_currentPreset]) _currentCustomUA = _customUAView.text ?: @"";
    _currentPreset = preset;
    [self refreshUAUI];
}

- (void)textViewDidChange:(UITextView *)textView {
    if (textView == _customUAView && [AMUAPresetManager isCustomPreset:_currentPreset]) _currentCustomUA = textView.text ?: @"";
}

- (void)pasteSession {
    NSString *value = UIPasteboard.generalPasteboard.string;
    if (value.length) _sessionField.text = value;
}

- (void)clearSession { _sessionField.text = @""; }

- (void)saveCurrentProfile {
    NSInteger index = AMProfileManager.sharedInstance.selectedProfileIndex;
    AMProfile *profile = [AMProfileManager.sharedInstance profileForIndex:index];
    profile.profileName = _profileNameField.text.length ? _profileNameField.text : [NSString stringWithFormat:@"Affiliate-%02ld", (long)index];
    profile.selectedUAPreset = _currentPreset;
    if ([AMUAPresetManager isCustomPreset:_currentPreset]) _currentCustomUA = _customUAView.text ?: @"";
    profile.customUserAgent = _currentCustomUA ?: @"";
    NSError *error = nil;
    BOOL ok = [AMProfileManager.sharedInstance saveProfile:profile sessionID:_sessionField.text ?: @"" error:&error];
    _saveStatusLabel.textColor = ok ? UIColor.systemGreenColor : UIColor.systemRedColor;
    _saveStatusLabel.text = ok ? @"Saved" : [NSString stringWithFormat:@"Save failed: %@", error.localizedDescription ?: @"unknown"];
    if (ok) [AMShadowbanMonitor.sharedInstance checkNow];
}

- (void)resetCurrentProfile {
    NSInteger index = AMProfileManager.sharedInstance.selectedProfileIndex;
    [AMProfileManager.sharedInstance resetProfileAtIndex:index];
    [self loadProfile:index];
    [AMShadowbanMonitor.sharedInstance checkNow];
}

- (void)openAccountPage {
    [self saveCurrentProfile];
    NSInteger index = AMProfileManager.sharedInstance.selectedProfileIndex;
    AMProfile *profile = [AMProfileManager.sharedInstance profileForIndex:index];
    _accountProfileLabel.text = [NSString stringWithFormat:@"Profile %ld · %@", (long)index, profile.profileName];
    _accountLogView.profileIndex = index;
    _accountResultLabel.text = @"保存済みのsessionidを自作アプリ側へ渡します。";
    [_navigation pushPage:_accountPage title:@"Account Switch"];
}

- (void)executeAccountSwitch {
    [self saveCurrentProfile];
    NSInteger index = AMProfileManager.sharedInstance.selectedProfileIndex;
    _accountResultLabel.text = @"切り替え中…";
    [AMAccountSwitchManager.sharedInstance switchToProfileIndex:index completion:^(BOOL success, NSString *message) {
        self->_accountResultLabel.textColor = success ? UIColor.systemGreenColor : UIColor.systemRedColor;
        self->_accountResultLabel.text = message;
    }];
}

@end
