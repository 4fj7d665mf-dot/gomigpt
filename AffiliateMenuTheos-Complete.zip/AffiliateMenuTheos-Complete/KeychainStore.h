#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMKeychainStore : NSObject
+ (nullable NSString *)sessionIDForProfileIndex:(NSInteger)profileIndex;
+ (BOOL)setSessionID:(NSString *)sessionID forProfileIndex:(NSInteger)profileIndex error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)deleteSessionIDForProfileIndex:(NSInteger)profileIndex error:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END
