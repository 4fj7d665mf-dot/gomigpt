#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^AMAccountSwitchCompletion)(BOOL success, NSString *message);

@interface AMAccountSwitchManager : NSObject
+ (instancetype)sharedInstance;
- (void)switchToProfileIndex:(NSInteger)profileIndex completion:(nullable AMAccountSwitchCompletion)completion;
@end

NS_ASSUME_NONNULL_END
