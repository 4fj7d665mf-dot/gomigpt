#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMMenuResizeController : NSObject
@property(nonatomic, strong, readonly) UIButton *resizeHandle;
- (instancetype)initWithPanel:(UIView *)panel hostWindow:(UIWindow *)window moveHandle:(UIView *)moveHandle;
- (void)updateHostWindow:(UIWindow *)window;
- (void)restoreAndClampFrame;
@end

NS_ASSUME_NONNULL_END
