#import "UAPresetManager.h"

@implementation AMUAPresetManager

+ (NSArray<NSNumber *> *)allPresets {
    return @[@(AMUAPresetSafariIOS), @(AMUAPresetSafariIPad), @(AMUAPresetChromeIPhone), @(AMUAPresetFirefoxIPhone), @(AMUAPresetEdgeIPhone), @(AMUAPresetCustom)];
}

+ (NSString *)titleForPreset:(AMUAPreset)preset {
    switch (preset) {
        case AMUAPresetSafariIOS: return @"Safari (iOS)";
        case AMUAPresetSafariIPad: return @"Safari (iPad)";
        case AMUAPresetChromeIPhone: return @"Chrome (iPhone)";
        case AMUAPresetFirefoxIPhone: return @"Firefox (iPhone)";
        case AMUAPresetEdgeIPhone: return @"Edge (iPhone)";
        case AMUAPresetCustom: return @"カスタム";
    }
    return @"Safari (iOS)";
}

+ (NSString *)userAgentForPreset:(AMUAPreset)preset {
    switch (preset) {
        case AMUAPresetSafariIOS:
            return @"Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1";
        case AMUAPresetSafariIPad:
            return @"Mozilla/5.0 (iPad; CPU OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1";
        case AMUAPresetChromeIPhone:
            return @"Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/131.0.0.0 Mobile/15E148 Safari/604.1";
        case AMUAPresetFirefoxIPhone:
            return @"Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/133.0 Mobile/15E148 Safari/605.1.15";
        case AMUAPresetEdgeIPhone:
            return @"Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) EdgiOS/131.0 Mobile/15E148 Safari/605.1.15";
        case AMUAPresetCustom:
            return @"";
    }
    return @"";
}

+ (BOOL)isCustomPreset:(AMUAPreset)preset {
    return preset == AMUAPresetCustom;
}

@end
