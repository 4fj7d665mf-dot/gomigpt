#import <UIKit/UIKit.h>

static const CGFloat AMMenuInitialWidth = 360.0;
static const CGFloat AMMenuInitialHeight = 560.0;
static const CGFloat AMMenuMinimumWidth = 300.0;
static const CGFloat AMMenuMinimumHeight = 360.0;
static const CGFloat AMMenuOuterMargin = 12.0;
static const CGFloat AMMenuHeaderHeight = 48.0;
static const CGFloat AMMenuControlHeight = 42.0;
