#import "Profile.h"

@implementation AMProfile

- (id)copyWithZone:(NSZone *)zone {
    AMProfile *copy = [[[self class] allocWithZone:zone] init];
    copy.index = self.index;
    copy.profileName = self.profileName;
    copy.selectedUAPreset = self.selectedUAPreset;
    copy.customUserAgent = self.customUserAgent;
    return copy;
}

@end
