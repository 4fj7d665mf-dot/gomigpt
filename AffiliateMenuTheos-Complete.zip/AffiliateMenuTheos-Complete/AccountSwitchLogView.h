#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMAccountSwitchLogView : UIView
@property(nonatomic, assign) NSInteger profileIndex;
- (void)reloadLog;
@end

NS_ASSUME_NONNULL_END
