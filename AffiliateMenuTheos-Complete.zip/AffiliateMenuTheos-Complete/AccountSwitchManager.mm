#import "AccountSwitchManager.h"
#import "AccountSwitchLogger.h"
#import "IntegrationContract.h"
#import "Profile.h"
#import "ProfileManager.h"
#import "UAPresetManager.h"

@implementation AMAccountSwitchManager {
    NSString *_activeToken;
    AMAccountSwitchCompletion _completion;
    NSInteger _activeProfileIndex;
}

+ (instancetype)sharedInstance {
    static AMAccountSwitchManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [AMAccountSwitchManager new]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(handleResult:) name:AMAccountSwitchResultNotification object:nil];
    }
    return self;
}

- (void)switchToProfileIndex:(NSInteger)profileIndex completion:(AMAccountSwitchCompletion)completion {
    dispatch_async(dispatch_get_main_queue(), ^{
        AMProfileManager *manager = AMProfileManager.sharedInstance;
        AMProfile *profile = [manager profileForIndex:profileIndex];
        NSString *sessionID = [manager sessionIDForProfileIndex:profileIndex];
        AMAccountSwitchLogger *logger = AMAccountSwitchLogger.sharedInstance;
        [logger appendMessage:@"Switch requested" level:@"INFO" profileIndex:profileIndex];
        [logger appendMessage:[NSString stringWithFormat:@"Profile: %@", profile.profileName] level:@"INFO" profileIndex:profileIndex];
        if (sessionID.length == 0) {
            [logger appendMessage:@"Session is empty; switch aborted" level:@"ERROR" profileIndex:profileIndex];
            if (completion) completion(NO, @"sessionid が空です");
            return;
        }
        [logger appendMessage:@"Session loaded from Keychain" level:@"INFO" profileIndex:profileIndex];

        self->_activeProfileIndex = profileIndex;
        self->_activeToken = NSUUID.UUID.UUIDString;
        self->_completion = [completion copy];
        NSString *ua = [AMUAPresetManager isCustomPreset:profile.selectedUAPreset] ? profile.customUserAgent : [AMUAPresetManager userAgentForPreset:profile.selectedUAPreset];
        NSDictionary *userInfo = @{
            AMIntegrationTokenKey:self->_activeToken,
            AMIntegrationProfileIndexKey:@(profileIndex),
            AMIntegrationProfileNameKey:profile.profileName ?: @"",
            AMIntegrationSessionIDKey:sessionID,
            AMIntegrationUserAgentKey:ua ?: @""
        };
        [logger appendMessage:@"Applying session through app integration" level:@"INFO" profileIndex:profileIndex];
        [NSNotificationCenter.defaultCenter postNotificationName:AMAccountSwitchRequestNotification object:self userInfo:userInfo];

        NSString *token = [self->_activeToken copy];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (![self->_activeToken isEqualToString:token]) return;
            [logger appendMessage:@"No integration result received (timeout)" level:@"ERROR" profileIndex:profileIndex];
            AMAccountSwitchCompletion pending = self->_completion;
            self->_activeToken = nil;
            self->_completion = nil;
            if (pending) pending(NO, @"自作アプリ側の切替ハンドラから応答がありません");
        });
    });
}

- (void)handleResult:(NSNotification *)notification {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSDictionary *info = notification.userInfo ?: @{};
        NSString *token = info[AMIntegrationTokenKey];
        if (!token || ![token isEqualToString:self->_activeToken]) return;
        BOOL success = [info[AMIntegrationSuccessKey] boolValue];
        NSString *message = info[AMIntegrationMessageKey] ?: (success ? @"Account switched" : @"Account switch failed");
        NSString *accountName = info[AMIntegrationAccountNameKey];
        AMAccountSwitchLogger *logger = AMAccountSwitchLogger.sharedInstance;
        [logger appendMessage:message level:(success ? @"OK" : @"ERROR") profileIndex:self->_activeProfileIndex];
        if (success && accountName.length) {
            [logger appendMessage:[NSString stringWithFormat:@"Account: %@", accountName] level:@"INFO" profileIndex:self->_activeProfileIndex];
        }
        AMAccountSwitchCompletion pending = self->_completion;
        self->_activeToken = nil;
        self->_completion = nil;
        if (pending) pending(success, message);
    });
}

@end
