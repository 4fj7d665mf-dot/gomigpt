#import "WindowResolver.h"
#import <math.h>

@implementation AMWindowResolver

+ (nullable UIWindow *)bestApplicationWindow {
    NSAssert(NSThread.isMainThread, @"Window resolution must run on the main thread");
    UIApplication *application = UIApplication.sharedApplication;
    NSArray<UIScene *> *scenes = application.connectedScenes.allObjects;

    UIWindow *window = [self bestWindowInScenes:scenes activationState:UISceneActivationStateForegroundActive];
    if (window) return window;
    return [self bestWindowInScenes:scenes activationState:UISceneActivationStateForegroundInactive];
}

+ (nullable UIWindow *)bestWindowInScenes:(NSArray<UIScene *> *)scenes activationState:(UISceneActivationState)state {
    for (UIScene *scene in scenes) {
        if (scene.activationState != state || ![scene isKindOfClass:UIWindowScene.class]) continue;
        UIWindow *candidate = [self bestWindowInWindowScene:(UIWindowScene *)scene];
        if (candidate) return candidate;
    }
    return nil;
}

+ (nullable UIWindow *)bestWindowInWindowScene:(UIWindowScene *)scene {
    NSArray<UIWindow *> *windows = scene.windows;
    for (UIWindow *window in windows) {
        if ([self isUsableWindow:window] && window.isKeyWindow) return window;
    }

    UIWindow *best = nil;
    CGFloat bestScore = -CGFLOAT_MAX;
    for (UIWindow *window in windows) {
        if (![self isUsableWindow:window]) continue;
        CGFloat levelPenalty = fabs(window.windowLevel - UIWindowLevelNormal) * 1000.0;
        CGFloat area = CGRectGetWidth(window.bounds) * CGRectGetHeight(window.bounds);
        CGFloat score = area - levelPenalty;
        if (score > bestScore) {
            bestScore = score;
            best = window;
        }
    }
    return best;
}

+ (BOOL)isUsableWindow:(UIWindow *)window {
    return !window.hidden && window.alpha > 0.01 && !CGRectIsEmpty(window.bounds);
}

@end
