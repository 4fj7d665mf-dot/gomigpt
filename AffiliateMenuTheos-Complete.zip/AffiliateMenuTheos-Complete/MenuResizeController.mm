#import "MenuResizeController.h"
#import "MenuLayoutMetrics.h"

static NSString * const AMMenuFrameKey = @"AffiliateMenu.panelFrame";

@implementation AMMenuResizeController {
    __weak UIView *_panel;
    __weak UIWindow *_window;
    UIButton *_resizeHandle;
    CGPoint _resizeStart;
    CGRect _resizeFrame;
    CGPoint _moveStart;
    CGRect _moveFrame;
}

- (instancetype)initWithPanel:(UIView *)panel hostWindow:(UIWindow *)window moveHandle:(UIView *)moveHandle {
    self = [super init];
    if (self) {
        _panel = panel;
        _window = window;
        [self installResizeHandle];
        UIPanGestureRecognizer *move = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleMove:)];
        [moveHandle addGestureRecognizer:move];
        moveHandle.userInteractionEnabled = YES;
    }
    return self;
}

- (UIButton *)resizeHandle { return _resizeHandle; }

- (void)installResizeHandle {
    _resizeHandle = [UIButton buttonWithType:UIButtonTypeSystem];
    [_resizeHandle setTitle:@"◢" forState:UIControlStateNormal];
    [_resizeHandle setTitleColor:[UIColor colorWithWhite:0.85 alpha:0.95] forState:UIControlStateNormal];
    _resizeHandle.titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightMedium];
    _resizeHandle.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.55];
    _resizeHandle.layer.cornerRadius = 8;
    _resizeHandle.translatesAutoresizingMaskIntoConstraints = NO;
    [_panel addSubview:_resizeHandle];
    [NSLayoutConstraint activateConstraints:@[
        [_resizeHandle.widthAnchor constraintEqualToConstant:44],
        [_resizeHandle.heightAnchor constraintEqualToConstant:44],
        [_resizeHandle.trailingAnchor constraintEqualToAnchor:_panel.trailingAnchor],
        [_resizeHandle.bottomAnchor constraintEqualToAnchor:_panel.bottomAnchor]
    ]];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleResize:)];
    [_resizeHandle addGestureRecognizer:pan];
}

- (void)updateHostWindow:(UIWindow *)window {
    _window = window;
    [self restoreAndClampFrame];
}

- (void)handleResize:(UIPanGestureRecognizer *)gesture {
    UIView *panel = _panel;
    UIWindow *window = _window;
    if (!panel || !window) return;
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _resizeStart = [gesture locationInView:window];
        _resizeFrame = panel.frame;
    }
    CGPoint current = [gesture locationInView:window];
    CGFloat dx = current.x - _resizeStart.x;
    CGFloat dy = current.y - _resizeStart.y;
    UIEdgeInsets safe = window.safeAreaInsets;
    CGFloat maxWidth = MAX(1.0, CGRectGetWidth(window.bounds) - safe.left - safe.right - AMMenuOuterMargin * 2);
    CGFloat maxHeight = MAX(1.0, CGRectGetHeight(window.bounds) - safe.top - safe.bottom - AMMenuOuterMargin * 2);
    CGFloat minWidth = MIN(AMMenuMinimumWidth, maxWidth);
    CGFloat minHeight = MIN(AMMenuMinimumHeight, maxHeight);
    CGFloat width = MIN(maxWidth, MAX(minWidth, CGRectGetWidth(_resizeFrame) + dx));
    CGFloat height = MIN(maxHeight, MAX(minHeight, CGRectGetHeight(_resizeFrame) + dy));
    CGRect frame = _resizeFrame;
    frame.size = CGSizeMake(width, height);
    panel.frame = [self clampedFrame:frame inWindow:window];
    if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled) [self persistFrame:panel.frame];
}

- (void)handleMove:(UIPanGestureRecognizer *)gesture {
    UIView *panel = _panel;
    UIWindow *window = _window;
    if (!panel || !window) return;
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _moveStart = [gesture locationInView:window];
        _moveFrame = panel.frame;
    }
    CGPoint current = [gesture locationInView:window];
    CGRect frame = _moveFrame;
    frame.origin.x += current.x - _moveStart.x;
    frame.origin.y += current.y - _moveStart.y;
    panel.frame = [self clampedFrame:frame inWindow:window];
    if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled) [self persistFrame:panel.frame];
}

- (CGRect)clampedFrame:(CGRect)frame inWindow:(UIWindow *)window {
    UIEdgeInsets safe = window.safeAreaInsets;
    CGFloat minX = safe.left + AMMenuOuterMargin;
    CGFloat minY = safe.top + AMMenuOuterMargin;
    CGFloat maxX = CGRectGetWidth(window.bounds) - safe.right - AMMenuOuterMargin - CGRectGetWidth(frame);
    CGFloat maxY = CGRectGetHeight(window.bounds) - safe.bottom - AMMenuOuterMargin - CGRectGetHeight(frame);
    frame.origin.x = MIN(MAX(frame.origin.x, minX), MAX(minX, maxX));
    frame.origin.y = MIN(MAX(frame.origin.y, minY), MAX(minY, maxY));
    return frame;
}

- (void)restoreAndClampFrame {
    UIView *panel = _panel;
    UIWindow *window = _window;
    if (!panel || !window) return;
    NSString *saved = [NSUserDefaults.standardUserDefaults stringForKey:AMMenuFrameKey];
    CGRect frame = saved.length ? CGRectFromString(saved) : CGRectZero;
    UIEdgeInsets safe = window.safeAreaInsets;
    CGFloat availableWidth = MAX(1.0, CGRectGetWidth(window.bounds) - safe.left - safe.right - AMMenuOuterMargin * 2);
    CGFloat availableHeight = MAX(1.0, CGRectGetHeight(window.bounds) - safe.top - safe.bottom - AMMenuOuterMargin * 2);
    CGFloat effectiveMinWidth = MIN(AMMenuMinimumWidth, availableWidth);
    CGFloat effectiveMinHeight = MIN(AMMenuMinimumHeight, availableHeight);
    if (CGRectIsEmpty(frame)) {
        CGFloat width = MIN(AMMenuInitialWidth, availableWidth);
        CGFloat height = MIN(AMMenuInitialHeight, availableHeight);
        frame = CGRectMake((CGRectGetWidth(window.bounds) - width) / 2.0, (CGRectGetHeight(window.bounds) - height) / 2.0, width, height);
    }
    frame.size.width = MAX(effectiveMinWidth, MIN(frame.size.width, availableWidth));
    frame.size.height = MAX(effectiveMinHeight, MIN(frame.size.height, availableHeight));
    panel.frame = [self clampedFrame:frame inWindow:window];
}

- (void)persistFrame:(CGRect)frame {
    [NSUserDefaults.standardUserDefaults setObject:NSStringFromCGRect(frame) forKey:AMMenuFrameKey];
}

@end
