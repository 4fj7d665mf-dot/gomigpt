#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AMMenuNavigationController : NSObject
@property(nonatomic, strong, readonly) UIView *rootView;
@property(nonatomic, strong, readonly) UIView *headerView;
@property(nonatomic, strong, readonly) UIButton *closeButton;
- (void)setRootPage:(UIView *)view title:(NSString *)title;
- (void)pushPage:(UIView *)view title:(NSString *)title;
- (void)popPage;
@end

NS_ASSUME_NONNULL_END
